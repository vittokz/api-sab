export default {
  database: {
    host: "localhost",
    user: "root",
    password: "root",
    database: "bd_sap",
  },
};
