import { Request, Response } from "express";
import * as XLSX from "xlsx";
import {
  EnumObservacionesAprobadas,
  EnumAutorizacionConceptos,
} from "../enum/observacionesAprobadas";
import { json } from "body-parser";

const pool = require("../database");
const regexPatterns = {
  soloNumeros: /^\d{1,20}$/,
  alfanumericos: /^(?!\s*$).{1,150}$/,
  fecha: /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/(19|20)\d{2}$/,
  preautorizacion: /^\s*([^\s].{0,59})?\s*$/,
};
const sqlQuery =
  "SELECT Numeroactualdelaprestacion, NDEAUTORIZACION, FECHARESPUESTAEPS, FechaVencimientoAUTORIZACION, NUMERO_PREAUTORIZACION FROM datos WHERE estado = 0 limit 7";
const sqlQueryConceptos = "SELECT * FROM reglas_proceso_auto";

class EstudiosMedicosController {
  constructor() {
    this.listEstudiosMedicos = this.listEstudiosMedicos.bind(this);
    this.listEstudiosMedicosError = this.listEstudiosMedicosError.bind(this);
    this.listEstudiosMedicosExcel = this.listEstudiosMedicosExcel.bind(this);
    this.processRows = this.processRows.bind(this);
    this.validateRow = this.validateRow.bind(this);
    this.isValidEstado = this.isValidEstado.bind(this);
    this.isValidEstadoPreautorizacion = this.isValidEstadoPreautorizacion.bind(this);
    this.listConceptos = this.listConceptos.bind(this);
  }

  validateRow(row: any, rowsConceptos: any) {
    const errors = [];
    let estadoProceso1 = 0;

    if (!regexPatterns.soloNumeros.test(row.Numeroactualdelaprestacion)) {
      errors.push(
        `Valor no válido en Numero actual de la prestación: ${
          row.Numeroactualdelaprestacion || null
        }`
      );
    }
    // Validar el campo N de Autorización según el campo Numero_Preautorizacion primer proceso
    if (row.NUMERO_PREAUTORIZACION) {
      if (
        this.isValidEstadoPreautorizacion(
          row.NUMERO_PREAUTORIZACION,
          rowsConceptos,
          "1"
        )
      ) {
        estadoProceso1 = 0;
      } else {
        //Validación segundo proceso
        if (
          this.isValidEstadoPreautorizacion(
            row.NUMERO_PREAUTORIZACION,
            rowsConceptos,
            "2"
          )
        ) {
          estadoProceso1 = 2;
          row.NDEAUTORIZACION = "";
          row.FECHARESPUESTAEPS = "";
          row.FechaVencimientoAUTORIZACION = "";
        } else {
          errors.push(
            `El número de Numero_Preautorizacion no es igual a ningun concepto del Segundo proceso :  ${
              row.NUMERO_PREAUTORIZACION || null
            }`
          );
        }
        // Si no coincide con los casos específicos, N de Autorización debe ser alfanumérico
        if (estadoProceso1 !== 2) {
          errors.push(
            `El valor del campo Numero_Preautorizacion no se encuentra en los conceptos definidos Primer proceso: ${
              row.NUMERO_PREAUTORIZACION || null
            }`
          );
        }
      }
    }

    if (
      !regexPatterns.alfanumericos.test(row.NDEAUTORIZACION) &&
      estadoProceso1 !== 2
    ) {
      errors.push(
        `Valor no válido en N DE AUTORIZACION: ${row.NDEAUTORIZACION || null}`
      );
    }
    if (
      !regexPatterns.fecha.test(row.FECHARESPUESTAEPS) &&
      estadoProceso1 !== 2
    ) {
      errors.push(
        `Valor no válido en FECHA RESPUESTA EPS: ${
          row.FECHARESPUESTAEPS || null
        }`
      );
    }
    if (
      !regexPatterns.fecha.test(row.FechaVencimientoAUTORIZACION) &&
      estadoProceso1 !== 2
    ) {
      errors.push(
        `Valor no válido en FECHA Vencimiento AUTORIZACION: ${
          row.FechaVencimientoAUTORIZACION || null
        }`
      );
    }
    if (
      !regexPatterns.alfanumericos.test(row.NUMERO_PREAUTORIZACION) &&
      estadoProceso1 !== 2
    ) {
      errors.push(
        `Valor no válido en NUMERO_PREAUTORIZACION: ${
          row.NUMERO_PREAUTORIZACION || null
        }`
      );
    }

    if (
      regexPatterns.fecha.test(row.FECHARESPUESTAEPS) &&
      regexPatterns.fecha.test(row.FechaVencimientoAUTORIZACION) &&
      estadoProceso1 === 0
    ) {
      const fechaRespuestaEps = new Date(
        row.FECHARESPUESTAEPS.split("/").reverse().join("-")
      );
      const fechaVencimientoAutorizacion = new Date(
        row.FechaVencimientoAUTORIZACION.split("/").reverse().join("-")
      );

      // Calcula la fecha mínima permitida para la FechaVencimientoAUTORIZACION
      const fechaMinima = new Date(fechaRespuestaEps);
      fechaMinima.setDate(fechaMinima.getDate() + 30);

      if (
        fechaVencimientoAutorizacion <= fechaRespuestaEps &&
        estadoProceso1 === 0
      ) {
        errors.push(
          `Fecha de Vencimiento de Autorización debe ser mayor que Fecha de Respuesta EPS: ${
            row.FechaVencimientoAUTORIZACION || null
          }`
        );
      } else if (
        fechaVencimientoAutorizacion < fechaMinima &&
        estadoProceso1 === 0
      ) {
        errors.push(
          `Fecha de Vencimiento de Autorización debe ser al menos 30 días después de la Fecha de Respuesta EPS: ${
            row.FechaVencimientoAUTORIZACION || null
          }`
        );
      }
    }

    return errors;
  }

  // Función para validar si un valor está en el enum Estado
  isValidEstado(value: string): boolean {
    return Object.values(EnumObservacionesAprobadas).includes(
      value.toUpperCase() as EnumObservacionesAprobadas
    );
  }

  // Función para validar si un valor está en el enum Estado
  isValidEstadoPreautorizacion(
    value: string,
    rowsConceptos: any,
    proceso: any
  ): boolean {
    return rowsConceptos.some(
      (row: any) => row.concepto.toUpperCase() === value.toUpperCase() && row.proceso === proceso
    );
  }

  public async listEstudiosMedicos(req: Request, res: Response) {
    try {
      pool.query(sqlQuery, (err: any, rows: any) => {
        if (err) throw err;
        try {
          pool.query(sqlQueryConceptos, (err: any, rowsConceptos: any) => {
            if (err) throw err;

            const { validRows, errorsPrimerProceso } = this.processRows(
              rows,
              rowsConceptos
            );
            const datosError: any = [];
            errorsPrimerProceso.forEach((row: any) => {
              datosError.push(row.row);
            });

            //realizar actualizacion del campo estado
          validRows.forEach((row: any) => {
            const updateQuery = `UPDATE datos SET estado = 1 WHERE Numeroactualdelaprestacion = ${row.Numeroactualdelaprestacion}`;
            pool.query(updateQuery, (err: any, result: any) => {
              if (err) {
                console.error(`Error actualizando el registro con Numeroactualdelaprestacion ${row.Numeroactualdelaprestacion}:`, err);
              } else {
                console.log(`Registro con id ${row.Numeroactualdelaprestacion} actualizado exitosamente.`);
              }
            });
          });

            return res.status(200).json({ validRows });
          });
        } catch (error) {
          console.error(
            "Error al obtener los conceptos de la base de datos:",
            error
          );
          res
            .status(500)
            .json({ error: `Error al obtener los conceptos. ${error}` });
        }
      });
    } catch (error) {
      console.error("Error al obtener los estudios médicos:", error);
      res
        .status(500)
        .json({ error: `Error al obtener los estudios médicos. ${error}` });
    }
  }

  public async listEstudiosMedicosExcel(req: Request, res: Response) {
    try {
      pool.query(sqlQuery, (err: any, rows: any) => {
        if (err) throw err;
        try {
          pool.query(sqlQueryConceptos, (err: any, rowsConceptos: any) => {
            if (err) throw err;
  
            const { validRows, errorsPrimerProceso } = this.processRows(rows, rowsConceptos);
            const datosError: any = [];
            errorsPrimerProceso.forEach((row: any) => {
              datosError.push(row.row);
            });
  
            // Crear un libro de trabajo de Excel
            const wb = XLSX.utils.book_new();
  
            // Agregar la hoja con los datos válidos
            const wsValidRows = XLSX.utils.json_to_sheet(validRows);
            XLSX.utils.book_append_sheet(wb, wsValidRows, 'Valid Rows');
  
            // Agregar la hoja con los datos con error (si los hay)
            if (datosError.length > 0) {
              const wsErrors = XLSX.utils.json_to_sheet(datosError);
              XLSX.utils.book_append_sheet(wb, wsErrors, 'Errors');
            }
  
            // Generar el archivo Excel en formato buffer
            const excelBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  
            // Configurar la respuesta para enviar el archivo Excel
            res.setHeader('Content-Disposition', 'attachment; filename="EstudiosMedicos.xlsx"');
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.send(excelBuffer);
          });
        } catch (error) {
          console.error('Error al obtener los conceptos de la base de datos:', error);
          res.status(500).json({ error: `Error al obtener los conceptos. ${error}` });
        }
      });
    } catch (error) {
      console.error('Error al obtener los estudios médicos:', error);
      res.status(500).json({ error: `Error al obtener los estudios médicos. ${error}` });
    }
  }

  // Listar data completa pero con errores
  public async listEstudiosMedicosError(req: Request, res: Response) {
    try {
      pool.query(sqlQuery, (err: any, rows: any) => {
        if (err) throw err;
        try {
          pool.query(sqlQueryConceptos, (err: any, rowsConceptos: any) => {
            if (err) throw err;
            
            const { validRows, errorsPrimerProceso } = this.processRows(
              rows,
              rowsConceptos
            );
            const datosError: any = [];
            errorsPrimerProceso.forEach((row: any) => {
              datosError.push(row.row);
            });

            return res.status(200).json({ errorsPrimerProceso });
          });
        } catch (error) {
          console.error(
            "Error al obtener los conceptos de la base de datos:",
            error
          );
          res
            .status(500)
            .json({ error: `Error al obtener los conceptos. ${error}` });
        }
      });
    } catch (error) {
      console.error("Error al obtener los estudios médicos:", error);
      res
        .status(500)
        .json({ error: `Error al obtener los estudios médicos. ${error}` });
    }
  }

  public processRows(rows: any[], rowsConceptos: any[]) {
    const validRows: any = [];
    const errorsPrimerProceso: any = [];
    rows.forEach((row: any) => {
      const errors = this.validateRow(row, rowsConceptos);
      if (errors.length > 0) {
        errorsPrimerProceso.push({ row, errors: errors });
      } else {
        validRows.push(row);
      }
    });
    return { validRows, errorsPrimerProceso };
  }

  //Listar los conceptos registrados en base de datos
  public async listConceptos(req: Request, res: Response) {
    try {
      pool.query(sqlQueryConceptos, (err: any, rows: any) => {
        if (err) throw err;
        return res.status(200).json({ conceptos: rows });
      });
    } catch (error) {
      console.error(
        "Error al obtener los conceptos de la base de datos:",
        error
      );
      res
        .status(500)
        .json({ error: `Error al obtener los conceptos. ${error}` });
    }
  }
}

export const estudiosMedicosController = new EstudiosMedicosController();